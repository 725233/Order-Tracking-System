"use client"

import * as React from "react"
import { Progress as ProgressPrimitive } from "radix-ui"
import { PackageCheck, Truck } from "lucide-react"

import { cn } from "@/lib/utils"

function Progress({
  className,
  value,
  ...props
}: React.ComponentProps<typeof ProgressPrimitive.Root>) {
  const progress = Math.min(100, Math.max(0, Number(value ?? 0)))
  const complete = progress >= 100

  return (
    <div className="relative pt-5">
      <span
        aria-hidden="true"
        className={cn(
          "absolute top-0 z-10 grid size-6 place-items-center rounded-full border bg-white shadow-sm transition-[left] duration-700 ease-out",
          complete ? "border-emerald-300 text-emerald-700" : "border-blue-300 text-[#0b6bcb]"
        )}
        style={{ left: `clamp(0px, calc(${progress}% - 12px), calc(100% - 24px))` }}
      >
        {complete ? <PackageCheck className="size-4" /> : <Truck className="size-4" />}
      </span>
      <ProgressPrimitive.Root
        data-slot="progress"
        value={progress}
        className={cn(
          "relative h-2 w-full overflow-hidden rounded-full bg-[#d9e7f5]",
          className
        )}
        {...props}
      >
        <ProgressPrimitive.Indicator
          data-slot="progress-indicator"
          className={cn("h-full w-full flex-1 transition-all duration-700", complete ? "bg-emerald-500" : "bg-[#0b6bcb]")}
          style={{ transform: `translateX(-${100 - progress}%)` }}
        />
      </ProgressPrimitive.Root>
    </div>
  )
}

export { Progress }
